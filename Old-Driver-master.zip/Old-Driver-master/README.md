# Old-Driver
For Google Girl Hackathon IV in Shanghai
# What is this project?
The player plays a role of a driver in New York University. You need to earn as much money as possible in one work day.
